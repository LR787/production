# 一言纯净API

作者:[沈唁](https://qq52o.me)  

博客:[https://qq52o.me/1801.html](https://qq52o.me/1801.html)  

## 请求示例

请求地址:[https://api.qq52o.me/hitokoto/](https://api.qq52o.me/hitokoto/)  

请求方式:`GET` 

请求编码:接口：`charset` 参数：`UTF-8/GBK` (默认`UTF-8`)  

请求参数:接口：`syz` 参数：`js`(为空则返回纯文本)  

返回内容:`我们从没有忘记真相，只是我们越来越会说谎。 `

